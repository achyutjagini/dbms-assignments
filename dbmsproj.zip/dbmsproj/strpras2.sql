\c lg;
start transaction;
CREATE OR REPLACE PROCEDURE SelectAllemployee(eEmail varchar(255)) 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer WHERE eEmail=eEmail 
$$; 