\c lg

insert into sale values (113456,500);
insert into sale values (113457,600);
insert into sale values (113458,500);
insert into sale values (113459,600);



insert into employee values (700,'Kayling','9051','1991-11-18','2005-12-10',6000,5042,'kayling@gmail.com','hdfc',113456);
insert into employee values (600,'Josh','9945','1987-04-20','2001-02-12',8000,5043,'josh@gmail.com','hdfc',113457);
insert into employee values (900,'Alex','7042','1988-02-12','2007-12-10',5000,5044,'alex@gmail.com','hdfc',113458);
insert into employee values (300,'Sebastian','9872','1990-12-10','2006-11-05',5000,5045,'seb@gmail.com','hdfc',113459);



insert into customer values (134252,'Tim','1980-05-11',997563,'tim@gmail.com','M','2019-04-12',700);
insert into customer values (147318,'Alice','2000-05-11',997563,'alice@gmail.com','F','2019-01-10',600);
insert into customer values (178492,'Ella','2001-05-11',99756,'ella@gmail.com','F','2018-07-09',900);
insert into customer values (119574,'Anna','1995-05-11',99756,'anna@gmail.com','F','2017-07-12',300);
/*insert into customer values (175948,'Bob','1993-05-11',99756,'bob@gmail.com','M','2019-11-13',68319);*/


insert into payments values (0,'cash',113456);
insert into payments values  (100,'cash',113457);
insert into payments values (200,'cash',113458);
insert into payments values  (300,'cash',113459);


insert into lg_product values (453,'Fridge',134252);
insert into lg_product values (454,'AC',147318);
insert into lg_product values (455,'Washing Machine',178492);
insert into lg_product values (456,'TV',119574); 


insert into lg_refrigerator values (453,'LG_6_Star',58433,90,0,30,'2025-02-03',80,20000);

insert into lg_AC values (454,'LG_5_Star',58434,90,0,30,'2025-02-03',80,20000);

insert into LG_WASHING_MACHINE values (455,'LG_abc',58434,90,'2025-02-03',30,40,80,20000,'top');

insert into LG_TV values (456,'LG_las',58434,90,'2025-02-03',30,60,'HD','large');

