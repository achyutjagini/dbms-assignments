INSERT INTO EMPLOYEE(eID,eName,ePhone,eDOB,eHireDate,eSalary,eAccNo,eEmail,eBank,eBillingID)
VALUES (683,'Kayling','9051','1991-11-18','2005-12-10',6000,5042,'kayling@gmail.com','hdfc',500);

INSERT INTO EMPLOYEE(eID,eName,ePhone,eDOB,eHireDate,eSalary,eAccNo,eEmail,eBank,eBillingID)
VALUES (347,'Josh','9945','1987-04-20','2001-02-12',8000,5043,'josh@gmail.com','hdfc',600);

INSERT INTO EMPLOYEE(eID,eName,ePhone,eDOB,eHireDate,eSalary,eAccNo,eEmail,eBank,eBillingID)
VALUES (894,'Alex','7042','1988-02-12','2007-12-10',5000,5044,'alex@gmail.com','hdfc',700);

INSERT INTO EMPLOYEE(eID,eName,ePhone,eDOB,eHireDate,eSalary,eAccNo,eEmail,eBank,eBillingID)
VALUES (704,'Sebastian','9872','1990-12-10','2006-11-05',5000,5045,'seb@gmail.com','hdfc',800);


INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (134251,Tim,1980-05-11,9975638563,tim@gmail.com,Male,2019-04-12,68319);

INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (147318,Alice,2000-05-11,9975638563,alice@gmail.com,Female,2019-01-10,34728);

INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (178492,Ella,2001-05-11,9975638563,ella@gmail.com,Female,2018-07-09,89421);

INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (119574,Anna,1995-05-11,9975638563,anna@gmail.com,Female,2017-07-12,70428);

INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (175948,Bob,1993-05-11,9975638563,bob@gmail.com,Male,2019-11-13,68319);

INSERT INTO CUSTOMER(cID,cName,cDOB,cPhone,cEmail,cGender,cLastPurchase,empID)
VALUE (112345,Joshua,1992-05-11,9975638563,joshua@gmail.com,Male,2019-03-12,89421);


INSERT INTO SALE(sBillingID,sTotalCost)
VALUE (113452,500);

INSERT INTO SALE(sBillingID,sTotalCost)
VALUE (123342,600);

INSERT INTO SALE(sBillingID,sTotalCost)
VALUE (43562,700);

INSERT INTO SALE(sBillingID,sTotalCost)
VALUE (245756,800);


INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (1400,card,);

INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (1300,online,);

INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (1700,cash,);

INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (1800,online,);

INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (2200,card,);

INSERT INTO PAYMENTS(pAmountDue,pModeOfPayment,pBillingID)
VALUE (1300,cash,);


INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (1342,AC,134251);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (2248,Washing_machine,147318);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (3652,Refrigerator,178492);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (4342,TV,119574);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (1956,AC,175948);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (2057,Washing_machine,112345);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (3342,Refrigerator,134251);

INSERT INTO LG_PRODUCT(lgID,lgName,custID)
VALUE (4542,TV,147318);


INSERT INTO LG_AC(acID,acName,acModel,acWeight,acMinTemp,acMaxTemp,acWarranty,acPrice,acElectricityInput)
VALUE ();


INSERT INTO LG_WASHING_MACHINE(wmID,wmName,wmModel,wmWeight,wmWarranty,wmLoadVolume,wmPrice,wmMotorType,wmElectricityInput,wmLoad)
VALUE ();


INSERT INTO LG_REFRIGERATOR(rID,rName,rModel,rWeight,rMinTemp,rMaxTemp,rWarranty,rLoadVolume,rPrice,rElectricityInput,rFreezer)
VALUE ();


INSERT INTO LG_TV(tvID,tvName,tvModel,tvWeight,tvWarranty,tvPrice,tvElectricityInput,tvScreen,tvType)
VALUE ();