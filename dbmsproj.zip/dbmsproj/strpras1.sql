\c lg;
start transaction;
CREATE OR REPLACE PROCEDURE SelectAllcustomer() 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer
$$; 