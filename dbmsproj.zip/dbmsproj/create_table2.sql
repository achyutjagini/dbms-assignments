drop database IF EXISTS lg;
create database lg;
\c lg

CREATE TABLE SALE(
    sBillingID bigint NOT NULL,
    sTotalCost bigint,
    PRIMARY KEY (sBillingID)
);

CREATE TABLE EMPLOYEE(
    eID bigint NOT NULL PRIMARY KEY,
    eName varchar(50) NOT NULL,
    ePhone bigint,
    eDOB Date,
    eHireDate Date,
    eSalary bigint,
    eAccNo bigint,
    eEmail varchar(255),
    eBank varchar(50),
    eBillingID bigint NOT NULL,
    FOREIGN KEY (eBillingID) REFERENCES SALE(sBillingID)
);

CREATE TABLE CUSTOMER(
    cID bigint NOT NULL PRIMARY KEY,
    cName varchar(50) NOT NULL,
    cDOB Date,
    cPhone bigint,
    cEmail varchar(255),
    cGender varchar(1),
    cLastPurchase Date,
    empID bigint NOT NULL,
    FOREIGN KEY (empID) REFERENCES EMPLOYEE(eID)
);

CREATE TABLE PAYMENTS(
    pAmountDue bigint,
    pModeOfPayment varchar(255),
    pBillingID bigint NOT NULL,
    FOREIGN KEY (pBillingID) REFERENCES SALE(sBillingID)
);

CREATE TABLE LG_PRODUCT(
    lgID bigint NOT NULL UNIQUE,
    lgName varchar(255) NOT NULL,
    custID bigint NOT NULL,
    PRIMARY KEY (lgID),
    FOREIGN KEY (custID) REFERENCES CUSTOMER(cID)
);

CREATE TABLE LG_AC(
    acID bigint NOT NULL,
    acName varchar(50),
    acModel bigint,
    acWeight bigint,
    acMinTemp bigint,
    acMaxTemp bigint,
    acWarranty Date,
    acPrice bigint,
    acElectricityInput bigint,
    FOREIGN KEY(acID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_WASHING_MACHINE(
    wmID bigint NOT NULL,
    wmName varchar(50) NOT NULL,
    wmModel bigint,
    wmWeight bigint,
    wmWarranty Date,
    wmLoadVolume bigint,
    wmPrice bigint,
    wmMotorType varchar(255),
    wmElectricityInput bigint,
    wmLoad varchar(9),
    FOREIGN KEY(wmID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_REFRIGERATOR(
    rID bigint NOT NULL,
    rName varchar(50) NOT NULL,
    rModel bigint,
    rWeight bigint,
    rMinTemp bigint,
    rMaxTemp bigint,
    rWarranty Date,
    rLoadVolume bigint,
    rPrice bigint,
    rElectricityInput bigint,
    rFreezer varchar(9),
    FOREIGN KEY(rID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_TV(
    tvID bigint NOT NULL,
    tvName varchar(50) NOT NULL,
    tvModel bigint,
    tvWeight bigint,
    tvWarranty Date,
    tvPrice bigint,
    tvElectricityInput bigint,
    tvScreen varchar(3),
    tvType varchar(9),
    FOREIGN KEY(tvID) REFERENCES LG_PRODUCT(lgID)
);