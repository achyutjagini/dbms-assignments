\c lg
CREATE OR REPLACE PROCEDURE SelectAllcustomer() 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer
$$; 

CREATE OR REPLACE PROCEDURE SelectAllemployee(eEmail varchar(255)) 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer WHERE eEmail=eEmail 
$$; 