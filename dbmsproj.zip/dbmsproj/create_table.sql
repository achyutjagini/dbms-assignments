drop database IF EXISTS lg;
create database lg;
\c lg

CREATE TABLE SALE(
    sBillingID int NOT NULL,
    sTotalCost int,
    PRIMARY KEY (sBillingID)
);

CREATE TABLE EMPLOYEE(
    eID int NOT NULL PRIMARY KEY,
    eName varchar(50) NOT NULL,
    ePhone varchar(12),
    eDOB Date,
    eHireDate Date,
    eSalary int,
    eAccNo int,
    eEmail varchar(255),
    eBank varchar(50),
    eBillingID int NOT NULL,
    FOREIGN KEY (eBillingID) REFERENCES SALE(sBillingID)
);

CREATE TABLE CUSTOMER(
    cID int NOT NULL PRIMARY KEY,
    cName varchar(50) NOT NULL,
    cDOB Date,
    cPhone int,
    cEmail varchar(255),
    cGender varchar(1),
    cLastPurchase Date,
    empID int NOT NULL,
    FOREIGN KEY (empID) REFERENCES EMPLOYEE(eID)
);

CREATE TABLE PAYMENTS(
    pAmountDue int,
    pModeOfPayment varchar(255),
    pBillingID int NOT NULL,
    FOREIGN KEY (pBillingID) REFERENCES SALE(sBillingID)
);

CREATE TABLE LG_PRODUCT(
    lgID int NOT NULL UNIQUE,
    lgName varchar(255) NOT NULL,
    custID int NOT NULL,
    PRIMARY KEY (lgID),
    FOREIGN KEY (custID) REFERENCES CUSTOMER(cID)
);

CREATE TABLE LG_AC(
    acID int NOT NULL,
    acName varchar(50),
    acModel int,
    acWeight int,
    acMinTemp int,
    acMaxTemp int,
    acWarranty Date,
    acPrice int,
    acElectricityInput int,
    FOREIGN KEY(acID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_WASHING_MACHINE(
    wmID int NOT NULL,
    wmName varchar(50) NOT NULL,
    wmModel int,
    wmWeight int,
    wmWarranty Date,
    wmLoadVolume int,
    wmPrice int,
    wmMotorType varchar(255),
    wmElectricityInput int,
    wmLoad varchar(9),
    FOREIGN KEY(wmID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_REFRIGERATOR(
    rID int NOT NULL,
    rName varchar(50) NOT NULL,
    rModel int,
    rWeight int,
    rMinTemp int,
    rMaxTemp int,
    rWarranty Date,
    rLoadVolume int,
    rPrice int,
    rElectricityInput int,
    rFreezer varchar(9),
    FOREIGN KEY(rID) REFERENCES LG_PRODUCT(lgID)
);

CREATE TABLE LG_TV(
    tvID int NOT NULL,
    tvName varchar(50) NOT NULL,
    tvModel int,
    tvWeight int,
    tvWarranty Date,
    tvPrice int,
    tvElectricityInput int,
    tvScreen varchar(3),
    tvType varchar(9),
    FOREIGN KEY(tvID) REFERENCES LG_PRODUCT(lgID)
);