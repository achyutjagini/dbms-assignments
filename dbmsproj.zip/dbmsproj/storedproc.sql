CREATE OR REPLACE PROCEDURE SelectAllname("email" varchar(250),mobile_no numeric(10)) 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer WHERE email=email AND mobile_no=mobile_no 
$$; 


CREATE PROCEDURE SelectAllcustomer() 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer
$$; 


CREATE PROCEDURE SelectAllcustomer(email varchar(30)) 
LANGUAGE SQL 
AS $$ 
SELECT * FROM customer WHERE email=email 
$$;